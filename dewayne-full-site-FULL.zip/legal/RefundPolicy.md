# Refund Policy

Digital goods are non-refundable after delivery of the download link.
