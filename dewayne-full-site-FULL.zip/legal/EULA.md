# End User License Agreement (EULA)

Digital downloads are licensed for personal use. No redistribution or resale.
